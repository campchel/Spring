package com.campbell.redbelt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedBeltApplicationTests {

	@Test
	void contextLoads() {
	}

}
