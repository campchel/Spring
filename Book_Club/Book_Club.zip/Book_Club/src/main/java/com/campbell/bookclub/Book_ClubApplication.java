package com.campbell.bookclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Book_ClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(Book_ClubApplication.class, args);
	}

}
